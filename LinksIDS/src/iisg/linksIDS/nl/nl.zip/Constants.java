package iisg.linksIDS.nl;

public class Constants {
	
	
	//static String node = "//10.24.62.219/";  // Hebe
	static String node  = "//10.24.64.152/";
	static String node2 = "//10.24.64.30/";
	//static String node = "//localhost/";
	

	
	static String links_match = node + "links_match?user=cor&password=q1w2e3r4";
	static String links_ids   = node + "links_ids?user=cor&password=q1w2e3r4";
	static String links_base  = node + "links_base?user=cor&password=q1w2e3r4";
	static String links_general  = node2 + "links_general?user=hsnref&password=refhsn";
	
	//static String links_match = node + "links_match?user=linksbeta&password=betalinks";
	//static String links_ids   = node + "LinksIDS?user=linksbeta&password=betalinks";
	//static String links_base  = node + "links_base?user=linksbeta&password=betalinks";
	
	//static String links_match = node + "links_match?user=oa2&password=abc123";
	//static String links_ids   = node + "LinksIDS?user=oa2&password=abc123";
	//static String links_base  = node + "links_base?user=oa2&password=abc123";
	
}
